package com.example.actividad2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.aplicacion2.MESSAGE";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sendMessage(View view){
        EditText etMensaje = findViewById(R.id.etMensaje),
                etNombre = findViewById(R.id.etNombre),
                etAsunto = findViewById(R.id.etAsunto),
                etEmail = findViewById(R.id.etEmail);

        final Intent enviarMensaje = new Intent( this, DisplayMessageActivity.class);
        String mensaje = etMensaje.getText().toString();
        String nombre = etNombre.getText().toString();
        String asunto = etAsunto.getText().toString();
        String email = etEmail.getText().toString();

        String message = "Nombre: " + " " + nombre + " " + "Email: " + email + " " +"Asunto: " + asunto + " " + "Mensaje: " + mensaje;

        enviarMensaje.putExtra(EXTRA_MESSAGE, message);
        startActivity(enviarMensaje);
    }

    public void LimpiarFormulario(View view){
        EditText etNombre = findViewById(R.id.etNombre),
                etEmail = findViewById(R.id.etEmail),
                etAsunto = findViewById(R.id.etAsunto),
                etMensaje = findViewById(R.id.etMensaje);

        etNombre.setText("");
        etEmail.setText("");
        etAsunto.setText("");
        etMensaje.setText("");

        final Intent mensaje = new Intent( this, DisplayMessageActivity.class);
        String message = etMensaje.getText().toString();
        mensaje.putExtra(EXTRA_MESSAGE, message);
        startActivity(mensaje);
    }

}