package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "com.example.myapplication.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void EnviarMensaje(View view) {
        Intent enviar = new Intent(this, Message.class);
        final EditText etSaludo = findViewById(R.id.etSaludo);
        String mensaje = etSaludo.getText().toString();
        enviar.putExtra(EXTRA_MESSAGE, mensaje);
        startActivity(enviar);
    }

    public void Llamar(View view) {
        Intent llamar = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:2311745579"));
        startActivity(llamar);
    }

    // Buscar cómo lanzar WhatsApp desde Intent
    public void IniciarWhatsApp(View view) {
        Intent  IniciarWhatsApp = getPackageManager().getLaunchIntentForPackage("com.whatsapp");
        startActivity(IniciarWhatsApp);
    }

    public void IniciarFacebook(View view) {
        Intent IniciarFacebook = getPackageManager().getLaunchIntentForPackage("com.facebook.katana");
        startActivity(IniciarFacebook);
    }

    public void IniciarTwitter(View view) {
        Intent IniciarTwitter = getPackageManager().getLaunchIntentForPackage("com.twitter.android");
        startActivity(IniciarTwitter);
    }

    public void IniciarInstagram(View view) {
        Intent IniciarInstagram = getPackageManager().getLaunchIntentForPackage("com.instagram.android");
        startActivity(IniciarInstagram);
    }

    public void IniciarTeams(View view) {
        Intent IniciarTeams = getPackageManager().getLaunchIntentForPackage("com.microsoft.teams");
        startActivity(IniciarTeams);
    }

    public void IniciarSkype(View view) {
        Intent  IniciarSkype =  getPackageManager().getLaunchIntentForPackage("com.skype.raider");
        startActivity(IniciarSkype);
    }

}